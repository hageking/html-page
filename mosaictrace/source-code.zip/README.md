# MosaicTrace prototype

An interactive photo-library review prototype with a sign-in screen, Photo Wall, person search, result details, and Settings.

## Run locally

```bash
npm install
npm run dev
```

The demo form is prefilled. Press **Sign in** to enter the prototype.

All photos, detected regions, match scores, and account details are fictional demo content. The prototype does not connect to a recognition API or an authentication service.
