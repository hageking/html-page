import { useMemo, useState } from "react";

const images = [
  { id: "p1", src: "./assets/photos/ethan-park.jpg", scene: "City park", date: "Today, 10:42 AM", confidence: 98 },
  { id: "p2", src: "./assets/photos/ethan-cafe.jpg", scene: "Coffee shop", date: "Yesterday, 4:16 PM", confidence: 96 },
  { id: "p3", src: "./assets/photos/ethan-trail.jpg", scene: "Mountain trail", date: "Sep 21, 2026", confidence: 94 },
  { id: "p4", src: "./assets/photos/ethan-cafe.jpg", scene: "Coffee shop", date: "Sep 20, 2026", confidence: 92 },
  { id: "p5", src: "./assets/photos/ethan-park.jpg", scene: "City park", date: "Sep 19, 2026", confidence: 90 },
  { id: "p6", src: "./assets/photos/ethan-trail.jpg", scene: "Mountain trail", date: "Sep 18, 2026", confidence: 89 },
  { id: "p7", src: "./assets/photos/ethan-park.jpg", scene: "City park", date: "Sep 17, 2026", confidence: 87 },
  { id: "p8", src: "./assets/photos/ethan-cafe.jpg", scene: "Coffee shop", date: "Sep 16, 2026", confidence: 85 },
  { id: "p9", src: "./assets/photos/ethan-trail.jpg", scene: "Mountain trail", date: "Sep 15, 2026", confidence: 83 },
  { id: "p10", src: "./assets/photos/ethan-cafe.jpg", scene: "Coffee shop", date: "Sep 14, 2026", confidence: 81 },
  { id: "p11", src: "./assets/photos/ethan-park.jpg", scene: "City park", date: "Sep 13, 2026", confidence: 79 },
  { id: "p12", src: "./assets/photos/ethan-trail.jpg", scene: "Mountain trail", date: "Sep 12, 2026", confidence: 76 },
  { id: "p13", src: "./assets/photos/ethan-park.jpg", scene: "City park", date: "Sep 11, 2026", confidence: 74 },
  { id: "p14", src: "./assets/photos/ethan-cafe.jpg", scene: "Coffee shop", date: "Sep 10, 2026", confidence: 72 },
  { id: "p15", src: "./assets/photos/ethan-trail.jpg", scene: "Mountain trail", date: "Sep 9, 2026", confidence: 70 },
  { id: "p16", src: "./assets/photos/ethan-cafe.jpg", scene: "Coffee shop", date: "Sep 8, 2026", confidence: 68 },
  { id: "p17", src: "./assets/photos/ethan-park.jpg", scene: "City park", date: "Sep 7, 2026", confidence: 66 },
  { id: "p18", src: "./assets/photos/ethan-trail.jpg", scene: "Mountain trail", date: "Sep 6, 2026", confidence: 63 },
  { id: "p19", src: "./assets/photos/ethan-cafe.jpg", scene: "Coffee shop", date: "Sep 5, 2026", confidence: 61 },
  { id: "p20", src: "./assets/photos/ethan-park.jpg", scene: "City park", date: "Sep 4, 2026", confidence: 59 },
  { id: "p21", src: "./assets/photos/ethan-trail.jpg", scene: "Mountain trail", date: "Sep 3, 2026", confidence: 57 },
  { id: "p22", src: "./assets/photos/ethan-cafe.jpg", scene: "Coffee shop", date: "Sep 2, 2026", confidence: 55 },
  { id: "p23", src: "./assets/photos/ethan-park.jpg", scene: "City park", date: "Sep 1, 2026", confidence: 53 },
  { id: "p24", src: "./assets/photos/ethan-trail.jpg", scene: "Mountain trail", date: "Aug 31, 2026", confidence: 51 },
  { id: "p25", src: "./assets/photos/ethan-cafe.jpg", scene: "Coffee shop", date: "Aug 30, 2026", confidence: 49 },
];

function Sidebar({ page, navigate }) {
  return (
    <aside className="sidebar">
      <button className="wordmark" onClick={() => navigate("home")} aria-label="MosaicTrace home">MosaicTrace</button>
      <nav className="primary-nav" aria-label="Main navigation">
        <button className={page === "home" ? "nav-item active" : "nav-item"} onClick={() => navigate("home")}>
          Home
        </button>
        <button className={page === "search" || page === "detail" ? "nav-item active" : "nav-item"} onClick={() => navigate("search")}>
          Search
        </button>
        <button className={page === "settings" ? "nav-item active" : "nav-item"} onClick={() => navigate("settings")}>
          Settings
        </button>
      </nav>
      <div className="sidebar-bottom">
        <span className="privacy-dot" />
        <div><strong>Private workspace</strong><p>Your photos stay in your library.</p></div>
      </div>
    </aside>
  );
}

function PhotoTile({ photo, index, onPersonClick, mode = "wall", selected = false, onSelect }) {
  return (
    <article className={`photo-tile ${mode === "match" ? "match-tile" : "wall-tile"} ${selected ? "is-selected" : ""}`}>
      <img src={photo.src} alt={`Synthetic photo of Ethan Carter in a ${photo.scene.toLowerCase()}`} loading={index > 8 ? "lazy" : "eager"} />
      {mode === "wall" ? (
        <button
          type="button"
          className={`detected-person ${index === 0 ? "show-hint" : ""}`}
          style={{ "--person-left": `${34 + (index % 3) * 2}%`, "--person-top": `${12 + (index % 2) * 3}%`, "--person-width": `${36 - (index % 3)}%`, "--person-height": `${65 - (index % 2) * 4}%` }}
          onClick={() => onPersonClick(photo)}
          aria-label={`Search for the detected person in ${photo.scene}`}
          title="Open person search"
        >
          <span className="detection-label">Ethan · Open Search</span>
        </button>
      ) : mode === "match" ? (
        <>
          <span className="confidence-label">{photo.confidence}%</span>
          <input
            type="checkbox"
            className={`select-photo ${selected ? "checked" : ""}`}
            checked={selected}
            onChange={() => onSelect(photo.id)}
            aria-label={`${selected ? "Remove" : "Select"} ${photo.scene} photo`}
          />
        </>
      ) : <span className="confidence-label">{photo.confidence}%</span>}
      <div className="photo-caption"><span>{photo.scene}</span><span>{photo.date}</span></div>
    </article>
  );
}

function Home({ onPersonClick, overlays }) {
  return (
    <section className="page home-page">
      <div className="page-heading">
        <div>
          <div className="eyebrow">YOUR LIBRARY</div>
          <h1>Photo Wall</h1>
          <p>Click a highlighted person to find related photos.</p>
        </div>
        <div className="library-count"><strong>{images.length}</strong><span>photos analyzed</span><b>·</b><span>1 person detected</span></div>
      </div>
      {overlays ? (
        <div className="photo-wall" aria-label="Photo library">
          {images.map((photo, index) => <PhotoTile key={photo.id} photo={photo} index={index} onPersonClick={onPersonClick} />)}
        </div>
      ) : (
        <div className="overlay-paused">
          <p>Person highlights are hidden.</p>
          <p>Turn them back on in Settings to select a person from a photo.</p>
        </div>
      )}
      <p className="api-note"><span className="api-dot" />People regions are shown from demo API data.</p>
    </section>
  );
}

function Search({ selectedPhoto, selectedIds, onToggle, onOpenDetail, onBackHome, onCombine }) {
  const [filter, setFilter] = useState("All matches");
  const matchImages = useMemo(() => [selectedPhoto, ...images.filter((photo) => photo.id !== selectedPhoto.id)].slice(0, 12), [selectedPhoto]);
  const filteredImages = useMemo(() => filter === "High confidence" ? matchImages.filter((photo) => photo.confidence >= 80) : matchImages, [filter, matchImages]);
  return (
    <section className="page search-page">
      <button className="text-back" onClick={onBackHome}>Back to Photo Wall</button>
      <div className="search-layout">
        <main className="search-main">
          <div className="page-heading search-heading">
            <div><div className="eyebrow">PERSON SEARCH</div><h1>Search</h1><p>Photos that may show the same person.</p></div>
            <label className="filter-control"><span>Show</span><select value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="Filter match confidence"><option>All matches</option><option>High confidence</option></select></label>
          </div>
          <div className="person-summary">
            <img src={selectedPhoto.src} alt="Ethan Carter" />
            <div className="person-summary-copy"><span className="summary-label">SELECTED PERSON</span><strong>Ethan Carter</strong><small>{matchImages.length} likely matches in this library</small></div>
            <button className="quiet-button" onClick={() => setFilter(filter === "All matches" ? "High confidence" : "All matches")}>{filter === "All matches" ? "High confidence only" : "Show all"}</button>
          </div>
          <div className="matches-heading"><div><h2>Possible matches</h2><p>Select photos that belong with this person.</p></div><span>{filteredImages.length} photos</span></div>
          <div className="match-grid">
            {filteredImages.map((photo, index) => (
              <PhotoTile key={photo.id} photo={photo} index={index} mode="match" selected={selectedIds.includes(photo.id)} onSelect={onToggle} />
            ))}
          </div>
        </main>
        <aside className="selected-panel">
          <div className="selected-panel-title"><div><span className="eyebrow">REVIEW & GROUP</span><h2>Selected Result</h2></div><span className="review-badge">Review</span></div>
          <button className="selected-person" onClick={onOpenDetail}>
            <img src={selectedPhoto.src} alt="Ethan Carter" />
            <span><strong>Ethan Carter</strong><small>Person ID · MT-45821</small><small>View person details</small></span>
          </button>
          <div className="candidate-section">
            <div className="candidate-heading"><h3>Possible same person</h3><p>Choose photos to combine.</p></div>
            <div className="candidate-list">
              {images.filter((photo) => photo.id !== selectedPhoto.id).slice(0, 5).map((photo) => {
                const checked = selectedIds.includes(photo.id);
                return (
                  <label className={`candidate-row ${checked ? "candidate-checked" : ""}`} key={photo.id}>
                    <input type="checkbox" checked={checked} onChange={() => onToggle(photo.id)} aria-label={`Combine ${photo.scene} photo`} />
                    <img src={photo.src} alt="" />
                    <span className="candidate-copy"><strong>{photo.scene}</strong><small>{photo.date}</small></span>
                    <span className="candidate-confidence">{photo.confidence}%</span>
                  </label>
                );
              })}
            </div>
          </div>
          <div className="combine-area">
            <button className="primary-button combine-button" disabled={selectedIds.length === 0} onClick={onCombine}>Combine selected <span>({selectedIds.length})</span></button>
            <p>Selected photos will appear under Ethan Carter.</p>
          </div>
        </aside>
      </div>
    </section>
  );
}

function Detail({ selectedPhoto, onBack, onReview, mergedCount }) {
  return (
    <section className="page detail-page">
      <button className="text-back" onClick={onBack}>Back to search results</button>
      <div className="detail-toolbar"><div className="eyebrow">PERSON DETAILS</div><button className="quiet-button" onClick={onReview}>Review matches</button></div>
      <div className="detail-hero">
        <img className="detail-portrait" src={selectedPhoto.src} alt="Synthetic profile photo of Ethan Carter" />
        <div className="detail-intro">
          <span className="eyebrow">SYNTHETIC PROFILE · MT-45821</span>
          <h1>Ethan Carter</h1>
          <p className="detail-confidence"><span /> 92% match confidence <b>·</b> Ready for review</p>
          <div className="detail-explanation"><h2>Why these photos are grouped</h2><p>The demo analysis finds similar visual features across photos taken in different scenes. Review each suggestion before combining it with this profile.</p></div>
          <div className="detail-facts"><div><span>Photos in group</span><strong>{12 + mergedCount}</strong></div><div><span>Common scenes</span><strong>Outdoor · Cafe</strong></div><div><span>Views found</span><strong>Front-facing · Angled</strong></div></div>
        </div>
      </div>
      <div className="detail-photos-heading"><div><h2>Related photos</h2><p>API supplied person regions · demo data</p></div><button className="primary-button" onClick={onReview}>Review matches</button></div>
      <div className="detail-photo-grid">{images.slice(0, 9).map((photo, index) => <PhotoTile key={photo.id} photo={photo} index={index} mode="detail" />)}</div>
    </section>
  );
}

function Settings({ overlays, setOverlays, requireReview, setRequireReview }) {
  return (
    <section className="page settings-page">
      <div className="page-heading"><div><div className="eyebrow">WORKSPACE PREFERENCES</div><h1>Settings</h1><p>Adjust how people and match suggestions appear.</p></div></div>
      <div className="settings-list">
        <div className="settings-row"><div><strong>Show detected people</strong><p>Display colored person regions on photos in the library.</p></div><button className={`toggle ${overlays ? "on" : ""}`} role="switch" aria-label="Show detected people" aria-checked={overlays} onClick={() => setOverlays(!overlays)}><span /></button></div>
        <div className="settings-row"><div><strong>Review before combining</strong><p>Keep a manual confirmation step before photos are grouped.</p></div><button className={`toggle ${requireReview ? "on" : ""}`} role="switch" aria-label="Review before combining" aria-checked={requireReview} onClick={() => setRequireReview(!requireReview)}><span /></button></div>
      </div>
      <div className="privacy-card"><span className="privacy-dot" /><div><strong>Private workspace</strong><p>This prototype uses fictional sample photos and local demo data.</p></div></div>
    </section>
  );
}

function Login({ onLogin }) {
  return (
    <main className="login-screen">
      <section className="login-pitch"><div className="wordmark login-wordmark">MosaicTrace</div><div className="login-pitch-copy"><div className="eyebrow">PRIVATE PHOTO REVIEW</div><h1>Find the same person across your photos.</h1><p>Review detected people, explore possible matches, and keep your library organized.</p><span className="login-privacy"><i /> Your library stays private</span></div><small className="login-footnote">A consent-based workspace for your own photo library.</small></section>
      <section className="login-form-side"><form className="login-form" onSubmit={(e) => { e.preventDefault(); onLogin(); }}><div className="eyebrow">WELCOME BACK</div><h2>Sign in to MosaicTrace</h2><p>Use the demo form to enter the prototype.</p><label>Email address<input type="email" placeholder="you@example.com" required defaultValue="demo@mosaictrace.app" /></label><label>Password<input type="password" placeholder="Enter your password" required defaultValue="mosaictrace" /></label><button className="primary-button login-submit" type="submit">Sign in</button><p className="login-demo-note">Demo account · no real sign-in required</p></form><span className="login-version">MosaicTrace prototype · 2026</span></section>
    </main>
  );
}

export function App() {
  const [page, setPage] = useState("login");
  const [selectedPhoto, setSelectedPhoto] = useState(images[0]);
  const [selectedIds, setSelectedIds] = useState([]);
  const [overlays, setOverlays] = useState(true);
  const [requireReview, setRequireReview] = useState(true);
  const [confirmMerge, setConfirmMerge] = useState(false);
  const [toast, setToast] = useState("");
  const [mergedCount, setMergedCount] = useState(0);

  const notify = (message) => {
    setToast(message);
    window.clearTimeout(notify.timer);
    notify.timer = window.setTimeout(() => setToast(""), 3200);
  };
  const openSearch = (photo) => {
    setSelectedPhoto(photo);
    setPage("search");
  };
  const togglePhoto = (id) => setSelectedIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  const completeCombine = () => {
    if (selectedIds.length === 0) return;
    const count = selectedIds.length;
    setMergedCount((current) => current + count);
    setSelectedIds([]);
    setConfirmMerge(false);
    notify(`${count} photo${count === 1 ? "" : "s"} combined with Ethan Carter.`);
  };
  const combine = () => {
    if (selectedIds.length === 0) return;
    if (requireReview) setConfirmMerge(true);
    else completeCombine();
  };

  if (page === "login") return <Login onLogin={() => setPage("home")} />;

  return (
    <div className="app-shell">
      <Sidebar page={page} navigate={setPage} />
      <div className="main-stage">
        {page === "home" && <Home onPersonClick={openSearch} overlays={overlays} />}
        {page === "search" && <Search selectedPhoto={selectedPhoto} selectedIds={selectedIds} onToggle={togglePhoto} onOpenDetail={() => setPage("detail")} onBackHome={() => setPage("home")} onCombine={combine} />}
        {page === "detail" && <Detail selectedPhoto={selectedPhoto} onBack={() => setPage("search")} onReview={() => setPage("search")} mergedCount={mergedCount} />}
      {page === "settings" && <Settings overlays={overlays} setOverlays={setOverlays} requireReview={requireReview} setRequireReview={setRequireReview} />}
      </div>
      {toast && <div className="toast" role="status">{toast}</div>}
      {confirmMerge && <div className="modal-backdrop"><section className="merge-dialog" role="dialog" aria-modal="true" aria-labelledby="merge-title"><span className="eyebrow">CONFIRM GROUPING</span><h2 id="merge-title">Combine these photos?</h2><p>{selectedIds.length} selected photo{selectedIds.length === 1 ? " will" : "s will"} be added to Ethan Carter.</p><div><button className="quiet-button" onClick={() => setConfirmMerge(false)}>Cancel</button><button className="primary-button" onClick={completeCombine}>Combine photos</button></div></section></div>}
    </div>
  );
}
